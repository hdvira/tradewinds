console.log('Worker started in safety-gated mode.');setInterval(()=>{},60000);
