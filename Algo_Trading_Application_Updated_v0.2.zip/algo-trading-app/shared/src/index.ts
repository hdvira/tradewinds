export type Environment='TEST'|'PRODUCTION'; export type Regime='NORMAL'|'VOLATILE'|'RISK_OFF';
export const regimeConfig=(r:Regime)=>r==='NORMAL'?{risk:.01,cap:.15,max:5}:r==='VOLATILE'?{risk:.005,cap:.10,max:3}:{risk:0,cap:0,max:0};
export const weightedAverage=(lots:{quantity:number;price:number}[])=>{const q=lots.reduce((s,x)=>s+x.quantity,0);return q?lots.reduce((s,x)=>s+x.quantity*x.price,0)/q:0};
export const targetPrice=(cost:number)=>cost*1.12; export const partialQty=(q:number)=>Math.floor(q*.5);
export const initialStop=(entry:number,atr:number)=>Math.max(0,entry-2*atr);
export const bulkQualifies=(buy:number,sell:number,parties:number)=>parties>=2&&buy>0&&sell/buy<.25;
export const bulkPremium=(live:number,reference:number)=>{const pct=(live/reference-1)*100;return{pct,state:pct<1?'WAIT':pct>6?'DO_NOT_CHASE':'PASS',eligible:pct>=1&&pct<=6}};
export function sizeBuy(portfolio:number,available:number,entry:number,stop:number,regime:Regime){const c=regimeConfig(regime);if(regime==='RISK_OFF')return 0;const riskPerShare=entry-stop;if(riskPerShare<=0)return 0;const riskQty=Math.floor(portfolio*c.risk/riskPerShare);const capQty=Math.floor(portfolio*c.cap/entry);const affordable=Math.floor(available/(entry*1.003));return Math.max(0,Math.min(riskQty,capQty,affordable));}
