# Development TODO

## Completed
- [x] TypeScript workspace structure
- [x] PostgreSQL username/password as separate `.env` values
- [x] `.env` excluded from source control
- [x] Initial schema and migration runner
- [x] TEST/REAL mode validation and adapter boundary
- [x] Bulk, budget, weighted-cost, target and sizing functions
- [x] Responsive Apple.com-inspired TEST/REAL dashboard shell
- [x] REST API shell and core tests

## Exact next starting point
- [ ] Install dependencies locally and commit package-lock.json
- [ ] Run migration and seed TEST budget
- [ ] Complete CSV import/deduplication repositories
- [ ] Complete Kite authentication and read-only APIs
- [ ] Implement market feed, indicators, regime and score persistence
- [ ] Implement transactional fund/slot reservations
- [ ] Implement TEST LIMIT fills and +12% GTT simulation
- [ ] Implement full Kite holdings/orders/trades/GTT reconciliation
- [ ] Expand all dashboard routes and perform scenario/recovery tests

Update this file after every development session.
