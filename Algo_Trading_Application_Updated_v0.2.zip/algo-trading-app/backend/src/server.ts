import express from'express';import cors from'cors';import{config}from'./config.js';import{query}from'./db.js';const app=express();app.use(cors());app.use(express.json());
app.get('/api/health',async(_q,r)=>{try{await query('select 1');r.json({status:'ok',mode:config.TEST_BUY_ENABLED?'TEST':'PRODUCTION'})}catch(e){r.status(503).json({status:'degraded',error:String(e)})}});
app.get('/api/dashboard/:env',async(q,r)=>{try{const x=await query('select * from dashboard_summary where environment=$1',[q.params.env.toUpperCase()]);r.json(x.rows[0]||{})}catch(e){r.status(503).json({error:String(e)})}});
app.get('/api/signals',async(q,r)=>r.json((await query('select * from signal where environment=$1 order by created_at desc limit 100',[q.query.environment||'TEST'])).rows));
app.get('/api/positions',async(q,r)=>r.json((await query("select * from position where environment=$1 and status<>'CLOSED'",[q.query.environment||'TEST'])).rows));
app.get('/api/orders',async(q,r)=>r.json((await query('select * from order_intent where environment=$1 order by created_at desc limit 100',[q.query.environment||'TEST'])).rows));
app.post('/api/positions/:id/lock',async(q,r)=>{await query('update position set auto_sell_locked=$1,updated_at=now() where position_id=$2',[!!q.body.locked,q.params.id]);r.json({ok:true})});
app.listen(config.PORT,'127.0.0.1',()=>console.log(`API http://127.0.0.1:${config.PORT}`));
