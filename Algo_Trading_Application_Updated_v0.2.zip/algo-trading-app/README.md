# Local Automated Equity Trading Platform v0.2

Local React + Node.js + PostgreSQL source baseline for delivery/CNC analysis, TEST/shadow execution, Bulk/Block intelligence, portfolio budget, +12% partial-profit logic, reconciliation, and safety-gated REAL execution.

## Apple.com-inspired interface

The dashboards use an original premium minimal design with large typography, generous whitespace, rounded surfaces, restrained color, responsive layouts, and clearly different TEST and REAL states. No Apple branding or proprietary assets are copied.

## PostgreSQL setup

Copy `.env.example` to `.env` and update:

```dotenv
POSTGRES_HOST=127.0.0.1
POSTGRES_PORT=5432
POSTGRES_DATABASE=algo_trading
POSTGRES_USER=postgres
POSTGRES_PASSWORD=your_password
POSTGRES_SSL=false
```

## Install and run

```bash
npm install
npm run db:migrate
npm test
npm run dev
```

Keep `REAL_BUY_ENABLED=false` and `REAL_SELL_ENABLED=false` until Kite integration and the complete scenario matrix are validated.

## Included

- React TEST/REAL dashboard shell
- Express local REST API
- PostgreSQL schema and migration runner
- Shared locked-rule calculations
- Tickertape V1 parser foundation
- TEST and Kite execution adapter boundary
- Core automated tests
- `.env.example`, `.gitignore`, and mandatory `todo.md`

## Current status

This is an updated development baseline, not a production-complete automated trader. Remaining work is explicitly tracked in `todo.md`.
